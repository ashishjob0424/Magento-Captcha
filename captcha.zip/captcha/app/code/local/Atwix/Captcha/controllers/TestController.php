<?php

/**
 * Created by PhpStorm.
 * User: ashish.madankar
 * Date: 18-05-2016
 * Time: 15:12
 */
class Atwix_Captcha_TestController extends Mage_Core_Controller_Front_Action
{
    public function formAction()
    {
        $this->loadLayout();
        $this->renderLayout();
    }

    public function validateAction()
    {
        $_data = $this->getRequest()->getPost();
        $_captcha = Mage::getModel('customer/session')->getData('form-validate-captcha_word');
        if ($_captcha['data'] == $_data['captcha']['form-validate-captcha']) {
            echo 'Well Done!';
        } else {
            echo 'You\'re disgusting robot!';
        }
        $this->loadLayout();
        $this->renderLayout();
    }

    public function refreshAction()
    {
        $formId = $this->getRequest()->getPost('formId', false);
        if ($formId) {
            $captchaModel = Mage::helper('captcha')->getCaptcha($formId);
            $this->getLayout()->createBlock('atwix_captcha/captcha_zend')->setFormId($formId)->setIsAjax(true)->toHtml();
            $this->getResponse()->setBody(json_encode(array('imgSrc' => $captchaModel->getImgSrc())));
        }
        $this->setFlag('', self::FLAG_NO_POST_DISPATCH, true);
    }
}