<?php

/**
 * Created by PhpStorm.
 * User: ashish.madankar
 * Date: 18-05-2016
 * Time: 15:04
 */
class Atwix_Captcha_Block_Captcha extends Mage_Captcha_Block_Captcha
{
    /**
     * Renders captcha HTML (if required)
     *
     * @return string
     */
    protected function _toHtml()
    {
        $blockPath = 'atwix_captcha/captcha_zend';
        $block = $this->getLayout()->createBlock($blockPath);
        $block->setData($this->getData());
        return $block->toHtml();
    }
    public function getActionOfForm()
    {
        return $this->getUrl('atwix-captcha/test/validate');
    }

    public function refresh()
    {
        return 'test';
    }


}